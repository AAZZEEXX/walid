module.exports = function () {
  return this.guides.length ? this.guides[0] : ''
}
