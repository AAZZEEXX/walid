module.exports = function () {
  return this.id || ''
}
