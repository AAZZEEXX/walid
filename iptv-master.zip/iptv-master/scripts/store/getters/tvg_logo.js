module.exports = function () {
  return this.logo || ''
}
